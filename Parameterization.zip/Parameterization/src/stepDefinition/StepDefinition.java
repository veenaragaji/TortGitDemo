package stepDefinition;
import static org.testng.Assert.assertEquals;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class StepDefinition {
	public WebDriver driver;
	@Given("^user Launch the application$")
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\hp au-620tx\\Desktop\\chromedriver_win32\\chromedriver.exe"); 
		driver=new ChromeDriver();
		driver.get("http://webapps.tekstac.com/shippingDetails/");
	}
	@SuppressWarnings("deprecation")
	@When("^user Test the Shipping Details is present in h(\\d+) tag$")
	public void testShippingDetails(int arg1) throws Exception {
		String title;
		title=driver.findElement(By.xpath("/html/body/div[1]/center/h2")).getText();
		Assert.assertEquals("Shipping Details", title);
	}

	@When("^user test the text \"([^\"]*)\" as a link$")
	public void user_test_the_text_as_a_link(String arg1) throws Exception {
		
		List<WebElement> l=driver.findElements(By.tagName("a"));
		for(WebElement e:l){
			
			if(e.getText().equals(arg1)){
				
				e.click();
			}
		}	
	}

	@Then("^verify shipment details are displayed$")
	public void verify_shipment_details_are_displayed() throws Exception  {
		String t1=driver.findElement(By.xpath("//*[@id='result']/table/tbody/tr[1]/td[1]/b")).getText();
		String t2=driver.findElement(By.xpath("//*[@id='result']/table/tbody/tr[1]/td[2]/b")).getText();
		
		assertEquals(t1, "Ship From");
		assertEquals(t2, "Ship To");
		
	}

	@Then("^verify \"([^\"]*)\" is present in the table\\.$")
	public void validateResult (String arg1){
		String name=driver.findElement(By.xpath("//*[@id='result']/table/tbody/tr[2]/td[1]")).getText();
		assertEquals(name, arg1);
		driver.close();
	}

	


	
}
